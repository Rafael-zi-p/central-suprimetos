# Consultas para criar no RM

Para cada consulta: **Gestão › Consultas SQL › Incluir**, cole o arquivo, teste e salve. Depois me informe o **código** e o **nome** com que foi cadastrada, e eu ligo no app (Configurações › Consultas TOTVS).

| # | Arquivo | Código sugerido | Sistema | Parâmetros | Para quê | Ação |
|---|---|---|---|---|---|---|
| 1 | `1-CUBO.SUP.OC (substituir).sql` | CUBO.SUP.OC | T | `DATAINI_D`, `DATAFIM_D` (datas) | OCs por item (mais rápida) | **substituir** o texto da atual, depois de comparar |
| 2 | `2-CUBO.SUP.FORN (nova).sql` | CUBO.SUP.FORN | T | nenhum | cadastro de fornecedores (aba Fornecedores, e-mail da OC) | **criar** |
| 3 | `3-CUBO.SUP.OCDOC (nova).sql` | CUBO.SUP.OCDOC | T | `CODCOLIGADA_N` (nº), `NUMEROMOV_S` (texto), `CODTMV_S` (texto, pode ir vazio) | dados completos de uma OC para o PDF | **criar** |
| 4 | `4-CUBO.SUP.CRONO (substituir).sql` | CUBO.SUP.CRONO | T | `CODCOLIGADA_N` (nº), `IDPRJ_N` (nº) | necessidades do orçamento por tarefa (Cronograma) | **substituir** o texto da sua CUBO.SUP.CRONO |
| 5 | `5-trecho para a CUBO.SUP.005 (alterar).sql` | CUBO.SUP.005 | (o da atual) | (os da atual) | acrescenta `DATA_APROVACAO_SC` à consulta de SC | **alterar**: acrescentar o trecho na consulta atual |

## Como testar antes de salvar

1. **CUBO.SUP.OC.** Rode a atual e a nova para o mesmo mês. Compare o nº de linhas e a soma de `VALOR_TOTAL_ITEM`: os dois têm de ser iguais.
2. **CUBO.SUP.FORN.** Deve trazer uma linha por fornecedor, sem repetir o código.
3. **CUBO.SUP.OCDOC.** Rode com uma coligada e uma OC conhecidas: vem uma linha por item.
4. **CUBO.SUP.CRONO.** Rode para um projeto, com a mesma coligada e o mesmo `IDPRJ` usados nas Verbas. Deve sair uma linha por necessidade.
   - Se der erro de "nome de coluna inválido", comente (`--`) a linha marcada com `[verificar]`.
5. **CUBO.SUP.005.** Confira se a coluna `DATA_APROVACAO_SC` aparece preenchida nas SCs aprovadas.

Em todas: libere a consulta para os mesmos usuários que já usam a CUBO.SUP.OC (na versão oficial, para o usuário de serviço).
